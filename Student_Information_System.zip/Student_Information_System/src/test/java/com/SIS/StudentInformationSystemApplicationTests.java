package com.SIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentInformationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
