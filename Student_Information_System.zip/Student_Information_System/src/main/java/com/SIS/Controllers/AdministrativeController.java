package com.SIS.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SIS.ObjectMapper.ObjectMapper;
import com.SIS.Proxies.Administartor;
import com.SIS.Proxies.EducationDetails;
import com.SIS.Proxies.FeeDetails;
import com.SIS.Proxies.Student;
import com.SIS.Repository.FeeDetailsServicesRepository;
import com.SIS.ServiceInterface.AdministartorServices;
import com.SIS.ServiceInterface.EducationDetailsServices;
import com.SIS.ServiceInterface.FeeDetailsServices;
import com.SIS.ServiceInterface.StudentServices;

@RestController
public class AdministrativeController {
	
	@Autowired private AdministartorServices adminInterFace;
	
	@Autowired private StudentServices  studentInterFace;
	
	@Autowired private EducationDetailsServices educationInter;
	
	@Autowired private FeeDetailsServices feeDetailsInter;
	
	@Autowired private ObjectMapper mapper;
	
	@Autowired private FeeDetailsServicesRepository feeRespo;
	
//	@Autowired private AdministartorServices Admini_InterObj;
	
	// signup Details, post
	@PostMapping(value = "/signupAdministartor")
	public ResponseEntity<String>SaveAdministartor(@RequestBody com.SIS.Proxies.Administartor administartorDto){

		return new ResponseEntity<String>(adminInterFace.SignupDetails(administartorDto), HttpStatus.OK);
		
	}
	//update User, post
	
	@PostMapping(value = "/updateUser/{id}")
	public ResponseEntity<String>updateUser(@RequestBody Student studentDto, @PathVariable("id") String enrollmentNo){
		return new ResponseEntity<String>(studentInterFace.updateStudent(studentDto, enrollmentNo), HttpStatus.ACCEPTED);
	}
	// update Admin , post
	@PostMapping(value = "/updateAdmin/{id}")
	public ResponseEntity<String>updateAdminDetails(@RequestBody Administartor administartorDto, @PathVariable("id")Long id){
		
		return new ResponseEntity<String>(adminInterFace.updateAdmin(administartorDto,id), HttpStatus.OK);
		
	}
	// delete user ,post
	@DeleteMapping(value = "/deleteUserById")
	public ResponseEntity<String> deleteUser(@PathVariable("id")String id){
		
		return new ResponseEntity<String>(studentInterFace.deleteStudentByID(id), HttpStatus.ACCEPTED);
		
	}
	// get user details get
	@GetMapping(value = "/getUserByid/{id}")
	public ResponseEntity<Student> getUserById( @PathVariable("id")String id){
		return new ResponseEntity<Student>(studentInterFace.getSingleStudent(id), HttpStatus.OK);
		
	}
	//get ALl users , get
	@GetMapping(value = "/getAllUsers")
	public ResponseEntity<List<Student>>getAllUsers(){
		return new ResponseEntity<List<Student>>(studentInterFace.getAllUsers(), HttpStatus.ACCEPTED);
		
	}
	// get Admin api , get
	@GetMapping(value = "/getAdminByid/{id}")
	public ResponseEntity<Administartor>getAdminDetails(@PathVariable ("id")Long id){
		
		return new ResponseEntity<Administartor>(adminInterFace.getAdminDetailsById(id), HttpStatus.ACCEPTED);
		
	}
	// add FeeDetails save , post
	@PostMapping(value = "/saveFeesDetails")
	public ResponseEntity<String>addFeesDetails(@RequestBody FeeDetails feeDetailsDto){
		
		return new ResponseEntity<String>(feeDetailsInter.saveFeesDetails(feeDetailsDto), HttpStatus.OK);
		
	}
	// get feesDetails ,get
	@GetMapping(value = "/getFees/{id}")
	public ResponseEntity<FeeDetails> getFeesDetails(@PathVariable("id")Long id){
		Optional<com.SIS.Entities.FeeDetails> byId = feeRespo.findById(id);
		if(byId.isPresent())
		{
			com.SIS.Entities.FeeDetails feeDetails = byId.get();
			FeeDetails feeDetailsDTO = mapper.entityToDto_FeesDetails(feeDetails);
			return new ResponseEntity<FeeDetails>(feeDetailsDTO, HttpStatus.ACCEPTED);
		
		}else {
			
			return null;
		}
		
	}
	
	// get EducationDetails , get
	@GetMapping(value = "getEducationDetails/{id}")
	public ResponseEntity<EducationDetails> getEducationDetails( @PathVariable("id")Long id){
		
		return new ResponseEntity<EducationDetails>(educationInter.getEducationDetails(id), HttpStatus.OK);
	}
	

}
