package com.SIS.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SIS.Proxies.EducationDetails;
import com.SIS.Proxies.FeeDetails;
import com.SIS.Proxies.Student;
import com.SIS.ServiceInterface.EducationDetailsServices;
import com.SIS.ServiceInterface.FeeDetailsServices;
import com.SIS.ServiceInterface.StudentServices;

@RestController
public class UserController {
	
	@Autowired private StudentServices studentInter;
	
	@Autowired private EducationDetailsServices educationDetailsServices;
	
	@Autowired private FeeDetailsServices feesInter;
	
	// Signup api ,post
	@PostMapping(value = "/SignupDetails")
	public ResponseEntity<String> SignupDetails(@RequestBody Student studentDto){
		return new ResponseEntity<String>(studentInter.signupDetails(studentDto), HttpStatus.OK);
		
	}
	// update api ,post  
	@PostMapping(value = "/updateUserDetails/{id}")
	public ResponseEntity<String>updateUser(@RequestBody Student studentDto, @PathVariable("id") String enrollmentNo){
		return new ResponseEntity<String>(studentInter.updateStudent(studentDto, enrollmentNo), HttpStatus.ACCEPTED);
	}

	// get ***
	@GetMapping(value = "/getUserID/{id}")
	public ResponseEntity<Student> getUserById( @PathVariable("id")String id){
		return new ResponseEntity<Student>(studentInter.getSingleStudent(id), HttpStatus.OK);
		
	}
	
	// get feesDetails 
	@GetMapping(value = "/getFeesDetails/{id}")
	public ResponseEntity<FeeDetails>getFeesDetails(@PathVariable("id")Long id){
		
		return new ResponseEntity<FeeDetails>(feesInter.getFeesDetailsById(id), HttpStatus.ACCEPTED);
		
	}
	// Add education save , post
	@PostMapping(value = "/saveEducation")
	public 	ResponseEntity<String> saveEducation(@RequestBody EducationDetails educationDetailsDto){
		return new ResponseEntity<String>(educationDetailsServices.EducationDetails(educationDetailsDto), HttpStatus.OK);
		
	}
	// update education post
	@PostMapping(value = "/updateEducation/{id}")
	public ResponseEntity<String>updateEducation(@RequestBody EducationDetails educationDetailsDto, @PathVariable("id")Long id){
		
		return new ResponseEntity<String>(educationDetailsServices.updateEducation(educationDetailsDto,id),HttpStatus.OK);
		
	}

}
