package com.SIS.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SIS.Entities.jwtEntity;
import com.SIS.Implementation.AuthImplementation;
import com.SIS.JwtUtils.JwtUtils;
import com.SIS.Repository.jwtEntityRepo;
import com.SIS.requestResponce.jwtRequest;
import com.SIS.requestResponce.jwtResponce;

@RestController
public class AuthController {
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired private AuthImplementation authImplementation;
	
	@Autowired private JwtUtils utilObject;
	
	@Autowired private jwtEntityRepo repo;
	
	@PostMapping(value = "/loginDetails")
	public ResponseEntity<jwtResponce>loginDetails(@RequestBody jwtRequest jwtRequest){
		
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(), jwtRequest.getPassword()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		UserDetails user = authImplementation.loadUserByUsername(jwtRequest.getUsername());
		String token = utilObject.generateToken(user);
		return new ResponseEntity<jwtResponce>(new jwtResponce(token), HttpStatus.OK);
		
	}
	
	@PostMapping(value = "/validate")
	public ResponseEntity<String>validateDetails(){
		return new ResponseEntity<String>("Working Done", HttpStatus.OK);
		
	}
	
	@PostMapping(value = "/saveData")
	public ResponseEntity<String>saveData(@RequestBody jwtEntity jwtEntity){
		jwtEntity jwtEntity2 = new jwtEntity();
		jwtEntity2.setPassword(jwtEntity.getPassword());
		jwtEntity2.setUsername(jwtEntity.getUsername());
		repo.save(jwtEntity2);
		return new ResponseEntity<String>("Data will be saved", HttpStatus.ACCEPTED);
	}

}
