package com.SIS.ServiceInterface;

import org.springframework.stereotype.Service;

import com.SIS.Proxies.EducationDetails;

@Service
public interface EducationDetailsServices {


	String EducationDetails(EducationDetails educationDetailsDto);

	String updateEducation(com.SIS.Proxies.EducationDetails educationDetailsDto, Long id);

	com.SIS.Proxies.EducationDetails getEducationDetails(Long id);

}
