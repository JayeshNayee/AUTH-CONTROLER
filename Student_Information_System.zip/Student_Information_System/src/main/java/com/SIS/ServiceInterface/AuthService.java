package com.SIS.ServiceInterface;

import org.springframework.stereotype.Service;

@Service
public interface AuthService {

}
