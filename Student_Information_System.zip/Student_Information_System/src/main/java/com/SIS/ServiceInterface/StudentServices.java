package com.SIS.ServiceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.SIS.Proxies.FeeDetails;
import com.SIS.Proxies.Student;

@Service
public interface StudentServices {

	String signupDetails(Student studentDto);

	FeeDetails getFeesDetailsById(Long id);

	String updateStudent(Student studentDto, String enrollmentNo);

	String deleteStudentByID(String id);

	Student getSingleStudent(String id);

	List<Student> getAllUsers();


}
