package com.SIS.ServiceInterface;

import org.springframework.stereotype.Service;

import com.SIS.Proxies.FeeDetails;

@Service
public interface FeeDetailsServices {

	FeeDetails getFeesDetailsById(Long id);

	String saveFeesDetails(FeeDetails feeDetailsDto);


}
