package com.SIS.ServiceInterface;

import org.springframework.stereotype.Service;

import com.SIS.Proxies.Administartor;

@Service
public interface AdministartorServices {

	String SignupDetails(Administartor administartor);
	
	//update User, post
	String updateAdmin(Administartor AdministartorDto, Long id);
	// delete user ,post
	// get user details get
	//get ALl users , get
	// get Admin api , get

	Administartor getAdminDetailsById(Long id);


	
	// add FeeDetails save , post
	// get feesDetails ,get
	// get EducationDetails , get
	

}
