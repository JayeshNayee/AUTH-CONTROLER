package com.SIS.Repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.SIS.Entities.Administartor;

@Repository
public interface AdministartorRepositry extends CrudRepository<Administartor, Long> {

}
