package com.SIS.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.SIS.Entities.EducationDetails;

@Repository
public interface EducationDetailsRepository extends CrudRepository<EducationDetails, Long> {

}
