package com.SIS.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SIS.Entities.Student;

@Repository
public interface StudentRepositry extends CrudRepository<Student, String> {

}
