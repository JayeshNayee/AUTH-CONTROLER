package com.SIS.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SIS.Entities.jwtEntity;

@Repository
public interface jwtEntityRepo extends CrudRepository<jwtEntity, String> {

}
