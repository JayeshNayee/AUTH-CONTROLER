package com.SIS.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SIS.Entities.FeeDetails;

@Repository
public interface FeeDetailsServicesRepository extends CrudRepository<FeeDetails, Long> {

}
