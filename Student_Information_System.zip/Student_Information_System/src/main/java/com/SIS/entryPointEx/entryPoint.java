package com.SIS.entryPointEx;

public class entryPoint {

}
