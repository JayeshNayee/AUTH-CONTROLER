package com.SIS.Implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SIS.ObjectMapper.ObjectMapper;
import com.SIS.Repository.EducationDetailsRepository;
import com.SIS.ServiceInterface.EducationDetailsServices;

@Component
public class EducationImplementation implements EducationDetailsServices{
	
	@Autowired private EducationDetailsRepository educationRepo;
	
	@Autowired private ObjectMapper objectMapper;

	
	@Override
	public String EducationDetails(com.SIS.Proxies.EducationDetails educationDetailsDto) {
		
		com.SIS.Proxies.EducationDetails education_Static_Dto = educationDetailsDto.Education_Static_Dto(null, educationDetailsDto.getStudent_enrollmentNo(), educationDetailsDto.getSemester(),educationDetailsDto.getPercentage(),educationDetailsDto.isQualified(), educationDetailsDto.getUpdatedBy(), educationDetailsDto.getUpdatedDate());
		
		com.SIS.Entities.EducationDetails educationDetailsEntity = objectMapper.dtoTOEntity_Education(educationDetailsDto);
		
		educationRepo.save(educationDetailsEntity);
		return "Education details will be saved";
	}


	@Override
	public String updateEducation(com.SIS.Proxies.EducationDetails educationDetailsDto, Long id) {
		
		Optional<com.SIS.Entities.EducationDetails> byId = educationRepo.findById(id);
		if(byId.isPresent())
		{
			
		com.SIS.Proxies.EducationDetails education_Static_Dto = educationDetailsDto.Education_Static_Dto(id, educationDetailsDto.getStudent_enrollmentNo(), educationDetailsDto.getSemester(), educationDetailsDto.getPercentage(), educationDetailsDto.isQualified(), educationDetailsDto.getUpdatedBy(), educationDetailsDto.getUpdatedDate());
		
		// convert it in entity 
		com.SIS.Entities.EducationDetails education_Entity = objectMapper.dtoTOEntity_Education(education_Static_Dto);
		System.out.println("updated "+ education_Entity);
		educationRepo.save(education_Entity);
		return "Education details will be update ";
		}
		else {
			return  "Id is not present ";
		}
	
	}


	@Override
	public com.SIS.Proxies.EducationDetails getEducationDetails(Long id) {
		
		Optional<com.SIS.Entities.EducationDetails> byId = educationRepo.findById(id);
		
		if(byId.isPresent())
		{
			com.SIS.Entities.EducationDetails educationDetails = byId.get();
			com.SIS.Proxies.EducationDetails EducationDto = objectMapper.entityToDto_Education(educationDetails);
			
			return EducationDto;
		}
		else {
			
			return null;
		}

	}

}



