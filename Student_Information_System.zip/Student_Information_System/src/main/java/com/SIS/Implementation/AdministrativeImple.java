package com.SIS.Implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SIS.ObjectMapper.ObjectMapper;
import com.SIS.Proxies.Administartor;
import com.SIS.Repository.AdministartorRepositry;
import com.SIS.ServiceInterface.AdministartorServices;

@Component
public class AdministrativeImple implements AdministartorServices {
	
	@Autowired private AdministartorRepositry adminRepo;
	
	@Autowired private ObjectMapper convertObjectMapper;
	
	@Autowired private ObjectMapper mapper;

	@Override
	public String SignupDetails(Administartor administartorDto) {
		
	Administartor admini_Dto = administartorDto.Admini_Dto(null, administartorDto.getPassword(), administartorDto.getName(), administartorDto.getGender(), administartorDto.getContact(), administartorDto.getAddress(),administartorDto.getCity(), administartorDto.getPinCode(), administartorDto.getSecurityKey());
	com.SIS.Entities.Administartor AdminEntity = convertObjectMapper.dtoTOEntity(administartorDto);
	System.out.println(AdminEntity);
	adminRepo.save(AdminEntity);
		return "Data will be saved ";
	}

	@Override
	public String updateAdmin(Administartor AdministartorDto, Long id) {
		
		Optional<com.SIS.Entities.Administartor> byId = adminRepo.findById(id);
		
		if(byId.isPresent())
		{
		com.SIS.Entities.Administartor administartorEntity = mapper.dtoTOEntity(AdministartorDto);
		
		adminRepo.save(administartorEntity);
		return "Administartor id  "+  id + " will be updated ";
		}else {
			
			return "Administartor " + id + "is not present ";
		}
	
	}

	@Override
	public Administartor getAdminDetailsById(Long id) {
		
		Optional<com.SIS.Entities.Administartor> byId = adminRepo.findById(id);
		
		if(byId.isPresent())
		{
			com.SIS.Entities.Administartor administartor = byId.get();
			Administartor administartorDto = mapper.entityToDto(administartor);
			
			return administartorDto;
		}else {
			
			return null;
		}
		
	}





}
