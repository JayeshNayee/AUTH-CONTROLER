package com.SIS.Implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SIS.ObjectMapper.ObjectMapper;
import com.SIS.Proxies.FeeDetails;
import com.SIS.Proxies.Student;
import com.SIS.Repository.EducationDetailsRepository;
import com.SIS.Repository.StudentRepositry;
import com.SIS.ServiceInterface.StudentServices;

@Component
public class UserImplementation implements StudentServices{
	
	@Autowired private ObjectMapper objectMapper;
	
	@Autowired private StudentRepositry studentRepo;
	
	@Autowired private EducationDetailsRepository educationRepo;

	@Override
	public String signupDetails(Student studentDto) {
		
		Student stuDto = studentDto.student_DtoStatic(studentDto.getEnrollmentNo(), studentDto.getPassword(), studentDto.getName(), studentDto.getGender(), studentDto.getDateOfBirth(), studentDto.getBranch(), studentDto.getContact(), studentDto.getAddress(), studentDto.getCity(), studentDto.getPinCode(), studentDto.getSecurityKey());
		com.SIS.Entities.Student studentEntity = objectMapper.dtoTOEntity_Student(stuDto);
		studentRepo.save(studentEntity);
		return "Student details will be saved ";
	}

	@Override
	public FeeDetails getFeesDetailsById(Long id) {
		
		return null;
	}

	@Override
	public String updateStudent(Student studentDto, String enrollmentNo) {
		
		if(!enrollmentNo.isEmpty())
		{
			Student student_EntityStatic = studentDto.student_DtoStatic(enrollmentNo, studentDto.getPassword(), studentDto.getName(), studentDto.getGender(), studentDto.getDateOfBirth(), studentDto.getBranch(), studentDto.getContact(), studentDto.getAddress(), studentDto.getCity(), studentDto.getPinCode(), studentDto.getSecurityKey());
			com.SIS.Entities.Student studentEntity = objectMapper.dtoTOEntity_Student(student_EntityStatic);
			studentRepo.save(studentEntity);
			return "These Student "+ enrollmentNo + " data will be updated";
		}
		else {
			
			return "Sorry your " +enrollmentNo  +  "is not present";
		}
		
	}

	@Override
	public String deleteStudentByID(String id) {
		if(studentRepo.findById(id) != null) {
			studentRepo.deleteById(id);
			return "These Student " + id +"  data will be deleted";
		}else {
			return "Id is not present ";
		}
	
	}

	@Override
	public Student getSingleStudent(String id) {
		
		Optional<com.SIS.Entities.Student> byId = studentRepo.findById(id);
		if(byId.isPresent())
		{
			com.SIS.Entities.Student student = byId.get();
			System.out.println("Get single data "+ byId.get());
			Student entityToDto_Student = objectMapper.entityToDto_Student(student);
			
			System.out.println("Entity Student Data " + entityToDto_Student);
			return entityToDto_Student;
		}else {
			return null;
			
		}

	}

	@Override
	public List<Student> getAllUsers() {
		
		List<com.SIS.Entities.Student> allStudentEntityList = (List<com.SIS.Entities.Student>) studentRepo.findAll();
		List<Student>studentsDtolList = new ArrayList<>();
			
			for (com.SIS.Entities.Student student : allStudentEntityList) {
				Student entityToDto_Student = objectMapper.entityToDto_Student(student);
				studentsDtolList.add(entityToDto_Student);
			}
			return studentsDtolList;
		
	}

}
