package com.SIS.Implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SIS.ObjectMapper.ObjectMapper;
import com.SIS.Proxies.FeeDetails;
import com.SIS.Repository.FeeDetailsServicesRepository;
import com.SIS.ServiceInterface.FeeDetailsServices;

@Component
public class FeesImplementation implements FeeDetailsServices {
	
	@Autowired private FeeDetailsServicesRepository feesRepo;
	
	@Autowired private ObjectMapper mapper;

	@Override
	public FeeDetails getFeesDetailsById(Long id) {
		
		Optional<com.SIS.Entities.FeeDetails> byId = feesRepo.findById(id);
		
		if(byId.isPresent())
		{
			com.SIS.Entities.FeeDetails feeDetails = byId.get();
			FeeDetails feeDetailsDto = mapper.entityToDto_FeesDetails(feeDetails);
			return feeDetailsDto;
		}else {
			return null;
		}
	}

	@Override
	public String saveFeesDetails(FeeDetails feeDetailsDto) {
		
		
		
		com.SIS.Entities.FeeDetails dtoTOEntity_FeesDetails = mapper.dtoTOEntity_FeesDetails(feeDetailsDto);
		feesRepo.save(dtoTOEntity_FeesDetails);
		
	//	feeDetailsDto.feesDetails_DTO(null, feeDetailsDto.getStudent_enrollmentNo(), feeDetailsDto.getFeeAmount(), feeDetailsDto.getDueDate(), feeDetailsDto.getUpdateDate(), feeDetailsDto.getUpdatedDate());
		return "Fees will be added";
	}

}
