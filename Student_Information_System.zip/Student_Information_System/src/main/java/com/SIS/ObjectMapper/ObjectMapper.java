package com.SIS.ObjectMapper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SIS.Entities.Student;
import com.SIS.Proxies.Administartor;
import com.SIS.Proxies.EducationDetails;
import com.SIS.Proxies.FeeDetails;

@Component
public class ObjectMapper {
	@Autowired com.fasterxml.jackson.databind.ObjectMapper mapper;
	/*Administartor*/
	
	
	
// entity to dto
	public  Administartor entityToDto(com.SIS.Entities.Administartor administartorEntity) {
		return mapper.convertValue(administartorEntity, Administartor.class);
	}
// dto to entity
	public com.SIS.Entities.Administartor dtoTOEntity(Administartor administartorDto) {
		return mapper.convertValue(administartorDto, com.SIS.Entities.Administartor.class);
	}
	
	
	
	/*Student convert*/
	
	// entity to dto
		public  com.SIS.Proxies.Student  entityToDto_Student(Student stuEntity) {
			return mapper.convertValue(stuEntity, com.SIS.Proxies.Student.class);
		}
	// dto to entity
		public Student dtoTOEntity_Student(com.SIS.Proxies.Student stuDto) {
			return mapper.convertValue(stuDto, Student.class);
		}
		
		/* Education converter*/
		
		// entity to dto
		public  EducationDetails  entityToDto_Education(com.SIS.Entities.EducationDetails educationEntity) {
			return mapper.convertValue(educationEntity, EducationDetails.class);
		}
		// dto to entity
		public com.SIS.Entities.EducationDetails dtoTOEntity_Education(EducationDetails educationDto) {
			return mapper.convertValue(educationDto, com.SIS.Entities.EducationDetails.class);
		}
		
		/*Fees details */
		
		// entity to dto
		public  FeeDetails  entityToDto_FeesDetails(com.SIS.Entities.FeeDetails feesEntity) {
			return mapper.convertValue(feesEntity, FeeDetails.class);
		}
		// dto to entity
		public com.SIS.Entities.FeeDetails dtoTOEntity_FeesDetails(FeeDetails feesDto) {
			return mapper.convertValue(feesDto, com.SIS.Entities.FeeDetails.class);
		}
//		public List<com.SIS.Proxies.Student> entityToDto_Student(List<Student> allStudentEntityList) {
//			return mapper.convertValue(allStudentEntityList, )
//			
//			
//		}
//		
		
	

}
