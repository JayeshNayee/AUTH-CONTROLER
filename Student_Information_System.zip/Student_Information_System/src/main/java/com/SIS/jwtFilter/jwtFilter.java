package com.SIS.jwtFilter;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.SIS.Implementation.AuthImplementation;
import com.SIS.JwtUtils.JwtUtils;


@Component
public class jwtFilter extends OncePerRequestFilter {
	
	@Autowired private JwtUtils utilsOb;
	
	@Autowired private AuthImplementation AuthImplementation1;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		String header  = null;
		String username = null;
		 header = request.getHeader("Authorization");
		if(header!=null && header.startsWith("Bearer "))
		{
			String token = header.substring(7);
			username = utilsOb.extractUsername(token);
		}
		if(username != null)
		{
			UserDetails userDetails = AuthImplementation1.loadUserByUsername(username);
			
			if(userDetails !=null && SecurityContextHolder.getContext().getAuthentication()==null)
			{
				UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(username,null, userDetails.getAuthorities());
				upToken.setDetails(new  WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(upToken);
			}
			
		}
		filterChain.doFilter(request, response);
	}

}
