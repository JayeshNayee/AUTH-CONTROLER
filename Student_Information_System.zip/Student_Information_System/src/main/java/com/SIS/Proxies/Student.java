package com.SIS.Proxies;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "student_DtoStatic")
@NoArgsConstructor
public class Student {

	private String enrollmentNo;
	private String password;
	private String name;
	private String gender;
	private  Date dateOfBirth;
	private String branch;
	private String contact;
	private String address;
	private String city;
	private String pinCode;
	private String securityKey;

}
