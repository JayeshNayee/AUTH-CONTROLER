package com.SIS.Proxies;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "Education_Static_Dto")
@NoArgsConstructor
public class EducationDetails {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String student_enrollmentNo;
	private String semester;
	private String percentage;
	private boolean qualified;
	private String updatedBy;
	private Date updatedDate;

}
